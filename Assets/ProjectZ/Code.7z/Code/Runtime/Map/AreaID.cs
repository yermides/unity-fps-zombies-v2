using UnityEngine;

namespace ProjectZ.Code.Runtime.Map
{
    [CreateAssetMenu(menuName = "ProjectZ/Area/ID", fileName = "ID_AREA_XX_XX", order = 0)]
    public class AreaID : ScriptableObject
    {
    }
}