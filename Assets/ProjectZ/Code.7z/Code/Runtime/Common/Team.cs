using System.Diagnostics.Tracing;

namespace ProjectZ.Code.Runtime.Common
{
    public enum Team
    {
        None,
        Character,
        Zombie,
    }
}