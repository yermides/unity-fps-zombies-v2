namespace ProjectZ.Code.Runtime.Common.Events
{
    public struct ZombieDiedEvent
    {
        public int InstanceID;
    }
}