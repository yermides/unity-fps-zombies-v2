namespace ProjectZ.Code.Runtime.Common.Events
{
    public struct RoundFinishedEvent
    {
        public int RoundNumber;
    }
}