namespace ProjectZ.Code.Runtime.Common.Events
{
    public struct InteractableDestroyedEvent
    {
        public int InstanceID;
    }
}