namespace ProjectZ.Code.Runtime.Common.Events
{
    public struct AllZombiesSpawnedEvent
    {
    }
}