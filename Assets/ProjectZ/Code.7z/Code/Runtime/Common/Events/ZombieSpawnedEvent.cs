namespace ProjectZ.Code.Runtime.Common.Events
{
    public struct ZombieSpawnedEvent
    {
        public int InstanceID;
    }
}