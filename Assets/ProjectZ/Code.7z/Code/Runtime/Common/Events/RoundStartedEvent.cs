namespace ProjectZ.Code.Runtime.Common.Events
{
    public struct RoundStartedEvent
    {
        public int RoundNumber;
    }
}