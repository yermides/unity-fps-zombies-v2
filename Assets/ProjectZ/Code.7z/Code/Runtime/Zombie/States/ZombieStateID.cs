namespace ProjectZ.Code.Runtime.Zombie.States
{
    public enum ZombieStateID
    {
        Chasing,
        DestroyingBarrier,
        Attacking,
    }
}