using System;
using ProjectZ.Code.Runtime.Common;
using UnityEngine;

namespace ProjectZ.Code.Runtime.Weapons
{
    public struct ProjectileArgs
    {
        public Team Team;
        public float Damage;
        public LayerMask LayerMask;
        public int Layer;
        public Action OnImpact;
    }

    public abstract class ProjectileBehaviour : MonoBehaviour
    {
        public event Action OnImpact;
        
        public abstract void Configure(ProjectileArgs args);
        public abstract void Configure(Team team, float damage);

        protected virtual void Start() { }

        private void OnCollisionEnter(Collision collision)
        {
            DoCollision(collision);
        }

        protected abstract void DoCollision(Collision collision);
    }
}