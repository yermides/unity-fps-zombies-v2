namespace ProjectZ.Code.Runtime.Utils
{
    public static class Tags
    {
        public const string Player = "Player";
    }
}