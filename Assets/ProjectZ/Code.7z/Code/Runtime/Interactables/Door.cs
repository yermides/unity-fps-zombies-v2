using ProjectZ.Code.Runtime.Character;
using ProjectZ.Code.Runtime.Map;
using UnityEngine;

namespace ProjectZ.Code.Runtime.Interactables
{
    public sealed class Door : InteractableBehaviour
    {
        // [SerializeField] public int cost;
        [SerializeField] private AreaID areaToOpen;
        
        public override void DoInteract(CharacterBehaviour character)
        {
            // Check if the player can buy door
            
            // If he does, trigger an event that the door was open passing the area id
            // and react to it inside the Area class, enabling the zombie spawn
            
            Destroy(gameObject, 1.0f);
        }
    }
}